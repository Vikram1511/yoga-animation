#!/bin/bash
while IFS='' read -r line || [[ -n "$line" ]]; do
    ./a.out $line "$2"
done < "$1"
